import java.net.*;
import java.io.*;

public class HTTPAsk {
    public static void main( String[] args) {
        // Your code here
    }
}

